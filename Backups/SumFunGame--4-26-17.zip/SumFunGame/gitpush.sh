#!/bin/bash

git pull origin master

git push origin master