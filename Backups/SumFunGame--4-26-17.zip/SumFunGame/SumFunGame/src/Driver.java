import java.io.IOException;
import java.text.ParseException;

public class Driver {

	public static void main(String[] args) throws ClassNotFoundException, IOException, ParseException {
		
		new UntimedGame();
		//new GameBoard();
	}

}